# Refonte glass — état au 7 octobre 2026

Reconstruction du balisage de **toutes les pages Juridique** sur la coquille « Glassy V22 »,
sans passer par Cline. Rien n'est poussé ni déployé.

## Ce qui a été fait

| Zone | Pages | État |
|---|---|---|
| Coquille | `layout.tsx`, `RoleLayout.tsx`, `Sidebar.tsx` | fond animé, colonne de verre, menu unique, compteurs, panneau mobile |
| Feuille de style | `src/styles/glass.css` (~800 l.) | jetons `--g-*`, composants `g-*`, couche de compatibilité, impression, reduced-motion |
| Admin | tableau de bord, présence, dossiers (+ échéances, constatations), nouveau, fiche, avancement, calendrier, recherche | glass complet |
| Juriste | tableau de bord, dossiers (+ nouveau, fiche), pointage, présence, avancement, calendrier, recherche | glass complet |
| Assistant | tableau de bord, pointage, présence, saisie, réception, scanner, documents | glass complet |
| Login | 2 colonnes navy + carte de verre | conserve `signIn('credentials')` |
| `/dashboard` | ancienne page qui recopiait le menu | redirige vers `/admin` |

La logique, les hooks, les routes, les magasins (`workflow-store`, `presence-demo`) et les
textes métier sont conservés. Seuls le balisage et l'habillage changent.

## Corrections de fond trouvées en chemin

- **Onglet Échéances imposé** sur `/admin/dossiers` : la vue par défaut est maintenant « Tous »,
  avec trois onglets (Tous / Échéances / Clos) et une URL propre `?etape=echeances`.
- **Identifiants bruts** (`person-juriste-1`) affichés dans les tableaux et bulles :
  remplacés par « Juriste 1 », « Assistant 2 »… via `PEOPLE`.
- **Minuteurs figés** : `admin/presence`, `juriste/presence`, `assistant/presence` battent
  désormais à la seconde.
- **Erreur d'hydratation React #418** sur les fiches dossier : le compteur de non-lus du menu
  changeait pendant l'hydratation. `markAsRead` est différé après montage et les compteurs
  portent `suppressHydrationWarning`.
- **Menu recopié** dans `src/app/dashboard/page.tsx` : supprimé (redirection).
- Champs de formulaire invisibles sur fond clair (saisie, scanner, documents) : arête et fond
  renforcés, sans toucher au login (fond sombre).

## Vérifications

- `npx tsc --noEmit` : 0 erreur.
- `npx next build` : succès (35 routes).
- Parcours Playwright des 28 routes : **0 erreur console**, **0 réponse 4xx**.
- Captures dans `/home/user/apercu-*.png`.

## À savoir

- Les minutes affichées (00:00:00, « 7 h 30 avant 7 h 30 ») viennent de l'horloge de la machine
  de test, calée avant l'heure de démarrage des shifts de démonstration (08:00).
- `src/components/presence/PresenceVdm.tsx` n'est importé nulle part : laissé tel quel.
- Aucun `git push`, aucun déploiement Vercel.
