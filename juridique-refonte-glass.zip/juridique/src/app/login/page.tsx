'use client'

import { Suspense, useEffect, useState, useSyncExternalStore, FormEvent, ChangeEvent } from 'react'
import { signIn, useSession } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { FlowLogo, FlowTag } from '@/components/brand/FlowBrand'
import {
  getLegalNoticeAcceptedServerSnapshot,
  getLegalNoticeAcceptedSnapshot,
  subscribeLegalNotice,
} from '@/components/brand/LegalNoticeModal'

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  )
}

function LoginForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { data: session, status } = useSession()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const fromFlow = searchParams.get('from') === 'flow'
  const [signedIn, setSignedIn] = useState(false)
  const legalAccepted = useSyncExternalStore(
    subscribeLegalNotice,
    getLegalNoticeAcceptedSnapshot,
    getLegalNoticeAcceptedServerSnapshot
  )
  const showLegalNotice = (signedIn || status === 'authenticated') && !legalAccepted

  useEffect(() => {
    const prefilled = searchParams.get('email')
    if (prefilled && prefilled.includes('@')) {
      setEmail(prefilled.trim().toLowerCase())
    }
  }, [])

  useEffect(() => {
    if (status !== 'authenticated' || !session?.user) return
    if (legalAccepted) {
      router.replace('/dashboard')
    }
  }, [status, session, legalAccepted, router])

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      const result = await signIn('credentials', {
        email,
        password,
        redirect: false,
      })

      if (result?.error) {
        setError('Email ou mot de passe invalide')
        return
      }

      setSignedIn(true)
      if (!legalAccepted) {
        router.replace('/legal-notice')
      } else {
        router.replace('/dashboard')
      }
    } catch (err) {
      setError('Une erreur est survenue lors de la connexion')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="g-login">
      <style>{CSS}</style>

      {/* Panneau gauche : signature ACX Flow */}
      <section className="g-login-left">
        <div className="g-login-halo g-login-halo--violet" aria-hidden="true" />
        <div className="g-login-halo g-login-halo--cyan" aria-hidden="true" />
        <div className="g-login-grid" aria-hidden="true" />

        <div className="g-login-left-inner">
          <div className="g-login-brand">
            <FlowLogo variant="light" height={34} />
            <FlowTag variant="light" />
          </div>

          <div className="g-login-pitch">
            <span className="g-login-chip"><i /> Espace Juridique</span>
            <h1>
              Votre équipe.{' '}
              <em>au même rythme.</em>
            </h1>
            <p>
              Gestion des dossiers juridiques, convocations, présence et suivi des échéances — réunis dans un espace
              unique, pensé pour l’activité juridique.
            </p>

            <div className="g-login-cards">
              {[
                { k: 'Dossiers', v: 'Réception · Traitement · Clôture' },
                { k: 'Présence', v: 'Pointage · Suivi · Équipe' },
                { k: 'Suivi', v: 'Étapes · Échéances · Statistiques' },
              ].map((item) => (
                <div key={item.k} className="g-login-card">
                  <span>{item.k}</span>
                  <b>{item.v}</b>
                </div>
              ))}
            </div>
          </div>

          <p className="g-login-copy">© 2026 ACX Maroc — Plateforme interne. Tous droits réservés.</p>
        </div>
      </section>

      {/* Panneau droit : connexion */}
      <section className="g-login-right">
        <div className="g-login-box">
          <div className="g-login-mobile-brand">
            <FlowLogo height={30} />
            <FlowTag />
          </div>

          <div className="g-glass g-login-card">
            <header>
              <h2>{fromFlow ? 'Espace Juridique' : 'Bienvenue'}</h2>
              <p>
                {fromFlow
                  ? 'Saisissez votre mot de passe pour continuer.'
                  : 'Connectez-vous à la plateforme ACX Flow.'}
              </p>
            </header>

            <form onSubmit={handleSubmit}>
              <div className="g-login-fields">
                {error && (
                  <div className="g-login-error" role="alert">{error}</div>
                )}

                {fromFlow && (
                  <div className="g-login-note">
                    <span aria-hidden="true" />
                    E-mail validé par le portail Flow — il ne reste que votre mot de passe.
                  </div>
                )}

                <label className="g-field">
                  <span>Email</span>
                  <input
                    id="email"
                    type="email"
                    placeholder="nom@vmanager.com"
                    value={email}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                    required
                    disabled={isLoading}
                    autoComplete="username"
                  />
                </label>

                <label className="g-field">
                  <span>Mot de passe</span>
                  <input
                    id="password"
                    type="password"
                    placeholder="Entrez votre mot de passe"
                    value={password}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
                    required
                    disabled={isLoading}
                    autoComplete="current-password"
                  />
                </label>
              </div>

              <div className="g-login-actions">
                <button type="submit" className="g-btn" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" style={{ animation: 'g-spin 1s linear infinite' }}>
                        <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" opacity="0.25" />
                        <path fill="currentColor" opacity="0.9" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      Connexion…
                    </>
                  ) : (
                    'Se connecter'
                  )}
                </button>

                <p className="g-login-help">
                  Pas de compte ?{' '}
                  <a href="mailto:support@acx.ma?subject=Demande%20de%20compte%20ACX%20Flow">
                    Contactez l’administrateur
                  </a>
                </p>

                <div className="g-login-demo">
                  <p>Accès démo</p>
                  <div>
                    <Link href="/admin">Admin</Link>
                    <Link href="/juriste">Juriste</Link>
                    <Link href="/assistant">Assistant</Link>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </section>

      {showLegalNotice && null}
    </div>
  )
}

const CSS = `
.g-login{display:grid;grid-template-columns:1.05fr 1fr;min-height:100vh;background:transparent;position:relative;z-index:1}
.g-login-left{
  position:relative;isolation:isolate;overflow:hidden;display:flex;
  padding:44px 52px;color:#fff;
  background:linear-gradient(155deg,#0b1330 0%,#0d1838 55%,#0a1228 100%);
}
.g-login-halo{position:absolute;border-radius:50%;filter:blur(60px);pointer-events:none}
.g-login-halo--violet{width:520px;height:520px;top:-200px;right:-140px;background:radial-gradient(circle,rgba(124,58,237,.55),transparent 68%)}
.g-login-halo--cyan{width:460px;height:460px;bottom:-220px;left:-160px;background:radial-gradient(circle,rgba(34,211,238,.45),transparent 68%)}
.g-login-grid{
  position:absolute;inset:0;opacity:.35;pointer-events:none;
  background-image:linear-gradient(rgba(255,255,255,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.06) 1px,transparent 1px);
  background-size:42px 42px;
  mask-image:radial-gradient(ellipse 80% 70% at 30% 20%,#000 20%,transparent 75%);
  -webkit-mask-image:radial-gradient(ellipse 80% 70% at 30% 20%,#000 20%,transparent 75%);
}
.g-login-left-inner{position:relative;z-index:1;display:flex;flex-direction:column;width:100%;gap:20px}
.g-login-brand{display:flex;flex-direction:column;align-items:flex-start;gap:10px}
.g-login-pitch{margin:auto 0;max-width:520px;padding:28px 0}
.g-login-chip{
  display:inline-flex;align-items:center;gap:9px;padding:7px 14px;border-radius:999px;
  border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);
  font-size:10.5px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:#d7e0f4;
}
.g-login-chip i{width:7px;height:7px;border-radius:50%;background:#26d4ea;box-shadow:0 0 0 5px rgba(38,212,234,.16)}
.g-login-pitch h1{margin:22px 0 0;font-size:clamp(32px,4vw,52px);line-height:1.06;letter-spacing:-.045em;font-weight:800}
.g-login-pitch h1 em{
  font-style:normal;background:linear-gradient(100deg,#67e8f9,#a78bfa);
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
.g-login-pitch p{margin:20px 0 0;max-width:440px;font-size:14.5px;line-height:1.6;color:#9eb0cc}
.g-login-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:32px;max-width:470px}
.g-login-card{
  border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);
  border-radius:16px;padding:14px;backdrop-filter:blur(8px);
}
.g-login-card span{display:block;font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:#26d4ea}
.g-login-card b{display:block;margin-top:6px;font-size:12px;line-height:1.4;font-weight:500;color:#c3cee4}
.g-login-copy{margin:0;font-size:11.5px;color:#7f90ae}

.g-login-right{display:flex;align-items:center;justify-content:center;padding:44px 24px}
.g-login-box{width:100%;max-width:440px}
.g-login-mobile-brand{display:none;flex-direction:column;align-items:center;gap:8px;margin-bottom:20px}
.g-login-card{padding:28px 26px 24px;border-radius:24px}
.g-login-card header h2{margin:0;font-size:25px;letter-spacing:-.035em;font-weight:760;color:var(--g-text)}
.g-login-card header p{margin:6px 0 0;font-size:13px;color:var(--g-muted)}
.g-login-fields{display:grid;gap:14px;margin-top:20px}
.g-login-error{
  padding:10px 12px;border-radius:12px;font-size:12.5px;font-weight:600;
  background:var(--g-bad-bg);color:var(--g-bad);border:1px solid rgba(180,35,24,.2);
}
.g-login-note{
  display:flex;align-items:center;gap:10px;padding:11px 13px;border-radius:12px;
  font-size:12.5px;color:var(--g-violet);
  background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.2);
}
.g-login-note span{width:7px;height:7px;border-radius:50%;background:var(--g-violet);box-shadow:0 0 0 4px rgba(124,58,237,.14);flex:0 0 7px}
.g-login-actions{margin-top:22px;display:grid;gap:14px}
.g-login-actions .g-btn{width:100%;height:44px}
.g-login-help{margin:0;text-align:center;font-size:12.5px;color:var(--g-muted)}
.g-login-help a{color:var(--g-violet);font-weight:700}
.g-login-help a:hover{text-decoration:underline;text-underline-offset:3px}
.g-login-demo{border-top:1px solid var(--g-line);padding-top:16px}
.g-login-demo p{margin:0 0 10px;text-align:center;font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--g-muted-2)}
.g-login-demo div{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.g-login-demo a{
  display:flex;align-items:center;justify-content:center;height:38px;border-radius:11px;
  border:1px solid var(--g-stroke);background:var(--g-glass-2);
  font-size:12px;font-weight:700;color:var(--g-text);transition:.2s;
}
.g-login-demo a:hover{border-color:rgba(37,99,235,.45);box-shadow:0 10px 22px rgba(37,99,235,.16);transform:translateY(-1px)}
@keyframes g-spin{to{transform:rotate(360deg)}}
@media (max-width:980px){
  .g-login{grid-template-columns:1fr}
  .g-login-left{display:none}
  .g-login-right{padding:28px 18px;min-height:100vh}
  .g-login-mobile-brand{display:flex}
}
@media (max-width:640px){
  .g-login-card{padding:22px 18px 20px;border-radius:20px}
  .g-login-card header h2{font-size:22px}
}
@media print{.g-login{display:block}}
`
