'use client';

/**
 * Même fichier pour :
 * src/app/admin/avancement/page.tsx
 * src/app/juriste/avancement/page.tsx
 * Bulle : clic sur une référence, boutons de sortie de ce dossier seul.
 * Notifier seulement sur Convocation : aperçu, aucun champ d'adresse.
 */

import { useState, useRef, useEffect, useCallback } from 'react';
import { useSyncExternalStore } from 'react';
import { usePathname } from 'next/navigation';
import { getWorkflowState, setWorkflowState, subscribeWorkflow, transitionCase } from '@/lib/workflow-store';
import { PEOPLE } from '@/lib/presence-demo';

type Status = 'delai' | 'retard' | 'attente' | 'clos';
function agentLabel(id?: string | null) {
  if (!id) return '-';
  const p = PEOPLE.find((x) => x.id === id);
  return p ? p.nom : id;
}

interface DossierItem { ref: string; lob: string; agent: string; juriste: string; statut: Status; detail: string; echeance: string | null; }
interface StepMeta { id: string; x: number; y: number; label: string; onglet: string; echeance: string; next: { id: string; label: string }[]; }
interface Arrow { from: string; d: string; join?: boolean; }
interface LabelItem { from: string; text: string; x: number; y: number; }

const W = 136, H = 56, BUS = 1188;

const STEP_META: StepMeta[] = [
  { id: 'constatation_recue', x: 342, y: 8, label: 'Constatation reçue', onglet: 'Constatations', echeance: '8 jours pour lancer l’analyse', next: [{ id: 'analyse_gravite', label: 'Lancer l’analyse' }] },
  { id: 'analyse_gravite', x: 342, y: 112, label: 'Analyse', onglet: 'Analyse', echeance: '8 jours après la réception', next: [{ id: 'convocation_seance', label: 'Faute grave' }, { id: 'sanction_faute_non_grave', label: 'Faute non grave' }] },
  { id: 'sanction_faute_non_grave', x: 24, y: 248, label: 'Sanction directe', onglet: 'Décisions', echeance: 'Pas de séance. Pas d’inspection.', next: [{ id: 'cloture', label: 'Clore' }] },
  { id: 'convocation_seance', x: 342, y: 248, label: 'Convocation', onglet: 'Convocations', echeance: '8 jours · présence non notée', next: [{ id: 'seance_presente', label: 'Présent' }, { id: 'seance_absente', label: 'Absent' }] },
  { id: 'seance_presente', x: 180, y: 400, label: 'Séance présente', onglet: 'Séances', echeance: 'Le papier reste dehors', next: [{ id: 'pv_seance', label: 'PV remis' }] },
  { id: 'pv_seance', x: 180, y: 528, label: 'PV de séance', onglet: 'Séances', echeance: 'Choix non saisi', next: [{ id: 'decision_licenciement', label: 'Licenciement' }, { id: 'decision_mise_a_pied', label: 'Mise à pied' }, { id: 'decision_sanction', label: 'Sanction' }, { id: 'fin_procedure', label: 'Absence du fait' }] },
  { id: 'seance_absente', x: 520, y: 400, label: 'Agent absent', onglet: 'Séances', echeance: 'Dépôt non saisi', next: [{ id: 'depot_inspection_absence', label: 'Déposer à l’inspection' }] },
  { id: 'depot_inspection_absence', x: 520, y: 528, label: 'Dépôt inspection', onglet: 'Décisions', echeance: 'Branche absence', next: [{ id: 'investigations', label: 'Ouvrir les investigations' }] },
  { id: 'investigations', x: 520, y: 656, label: 'Investigations', onglet: 'Décisions', echeance: 'L’outil note l’ouverture. Il n’enquête pas.', next: [{ id: 'decision_licenciement', label: 'Licenciement' }, { id: 'decision_mise_a_pied', label: 'Mise à pied' }, { id: 'decision_sanction', label: 'Sanction' }, { id: 'fin_procedure', label: 'Absence du fait' }] },
  { id: 'decision_licenciement', x: 180, y: 820, label: 'Licenciement', onglet: 'Décisions', echeance: 'Puis les 48 heures', next: [{ id: 'notification_48h', label: 'Rappel des 48 heures' }] },
  { id: 'decision_mise_a_pied', x: 340, y: 820, label: 'Mise à pied', onglet: 'Décisions', echeance: 'Puis les 48 heures', next: [{ id: 'notification_48h', label: 'Rappel des 48 heures' }] },
  { id: 'decision_sanction', x: 500, y: 820, label: 'Sanction', onglet: 'Décisions', echeance: 'Pas d’inspection', next: [{ id: 'cloture', label: 'Clore' }] },
  { id: 'fin_procedure', x: 660, y: 820, label: 'Absence du fait', onglet: 'Décisions', echeance: 'Pas d’inspection', next: [{ id: 'cloture', label: 'Clore' }] },
  { id: 'notification_48h', x: 230, y: 960, label: 'Rappel 48 h', onglet: 'Décisions', echeance: '48 heures. Visible aussi dans Échéances.', next: [{ id: 'depot_inspection_decision', label: 'Dépôt à l’inspection' }] },
  { id: 'depot_inspection_decision', x: 230, y: 1088, label: 'Dépôt inspection', onglet: 'Décisions', echeance: 'Après les 48 heures', next: [{ id: 'cloture', label: 'Clore' }] },
  { id: 'cloture', x: 342, y: 1216, label: 'Clos', onglet: 'Clos', echeance: 'Aucune branche ouverte', next: [] },
];

export default function AvancementPage() {
  const snap = useSyncExternalStore(subscribeWorkflow, getWorkflowState, getWorkflowState);
  const base = (usePathname() || '').startsWith('/juriste') ? '/juriste' : '/admin';
  const [picked, setPicked] = useState<string | null>(null);
  const [mailRef, setMailRef] = useState<string | null>(null);
  const [notice, setNotice] = useState('');
  const byId = Object.fromEntries(STEP_META.map(s => [s.id, s]));
  function dossiersFor(code: string): DossierItem[] {
    return snap.cases.filter(c => c.etape === code).map(c => {
      const late = !!c.echeance && new Date(c.echeance) < new Date();
      const clos = c.etape === 'cloture';
      const statut: Status = clos ? 'clos' : late ? 'retard' : c.echeance ? 'delai' : 'attente';
      const dateStr = c.echeance ? new Date(c.echeance).toLocaleDateString('fr-FR') : '';
      const detail = clos ? 'Clos · aucune branche ouverte' : late ? `En retard · échéance dépassée le ${dateStr}` : c.echeance ? `Dans le délai · échéance ${dateStr}` : 'En attente · aucune échéance';
      return { ref: c.reference, lob: c.affectationFixe?.lob || '-', agent: agentLabel(c.agentId), juriste: c.juriste?.nom || '-', statut, detail, echeance: c.echeance ?? null };
    });
  }
  const steps = STEP_META.map(m => ({ ...m, dossiers: dossiersFor(m.id) }));
  const count = (step: { dossiers: DossierItem[] }, kind: Status) => step.dossiers.filter(d => d.statut === kind).length;
  const [selectedId, setSelectedId] = useState<string | null>('analyse_gravite');
  const popRef = useRef<HTMLDivElement>(null);
  const [popStyle, setPopStyle] = useState<{ left: number; top: number; cls: string; tail: number } | null>(null);
  const CX = (id: string) => byId[id].x + W / 2;
  const B = (id: string) => byId[id].y + H;
  const T = (id: string) => byId[id].y;
  const arrows = [
    { from: 'constatation_recue', d: `M ${CX('constatation_recue')} ${B('constatation_recue')} V ${T('analyse_gravite')}` },
    { from: 'analyse_gravite', d: `M ${CX('analyse_gravite')} ${B('analyse_gravite')} V 196 H ${CX('sanction_faute_non_grave')} V ${T('sanction_faute_non_grave')}` },
    { from: 'analyse_gravite', d: `M ${CX('analyse_gravite')} ${B('analyse_gravite')} V ${T('convocation_seance')}` },
    { from: 'sanction_faute_non_grave', d: `M ${CX('sanction_faute_non_grave')} ${B('sanction_faute_non_grave')} V ${BUS} H ${CX('cloture')} V ${T('cloture')}` },
    { from: 'convocation_seance', d: `M ${CX('convocation_seance')} ${B('convocation_seance')} V 352 H ${CX('seance_presente')} V ${T('seance_presente')}` },
    { from: 'convocation_seance', d: `M ${CX('convocation_seance')} ${B('convocation_seance')} V 352 H ${CX('seance_absente')} V ${T('seance_absente')}` },
    { from: 'seance_presente', d: `M ${CX('seance_presente')} ${B('seance_presente')} V ${T('pv_seance')}` },
    { from: 'seance_absente', d: `M ${CX('seance_absente')} ${B('seance_absente')} V ${T('depot_inspection_absence')}` },
    { from: 'depot_inspection_absence', d: `M ${CX('depot_inspection_absence')} ${B('depot_inspection_absence')} V ${T('investigations')}` },
    { from: 'pv_seance', d: `M ${CX('pv_seance')} ${B('pv_seance')} V 748 H 488 V 772`, join: true },
    { from: 'investigations', d: `M ${CX('investigations')} ${B('investigations')} V 748 H 488`, join: true },
    { from: 'pv investig', d: `M ${CX('decision_licenciement')} 772 V ${T('decision_licenciement')}` },
    { from: 'pv investig', d: `M ${CX('decision_mise_a_pied')} 772 V ${T('decision_mise_a_pied')}` },
    { from: 'pv investig', d: `M ${CX('decision_sanction')} 772 V ${T('decision_sanction')}` },
    { from: 'pv investig', d: `M ${CX('fin_procedure')} 772 V ${T('fin_procedure')}` },
    { from: 'pv investig', d: `M ${CX('decision_licenciement')} 772 H ${CX('fin_procedure')}`, join: true },
    { from: 'decision_licenciement', d: `M ${CX('decision_licenciement')} ${B('decision_licenciement')} V 918 H ${CX('notification_48h')} V ${T('notification_48h')}` },
    { from: 'decision_mise_a_pied', d: `M ${CX('decision_mise_a_pied')} ${B('decision_mise_a_pied')} V 918 H ${CX('notification_48h')} V ${T('notification_48h')}` },
    { from: 'notification_48h', d: `M ${CX('notification_48h')} ${B('notification_48h')} V ${T('depot_inspection_decision')}` },
    { from: 'depot_inspection_decision', d: `M ${CX('depot_inspection_decision')} ${B('depot_inspection_decision')} V ${BUS} H ${CX('cloture')} V ${T('cloture')}` },
    { from: 'decision_sanction', d: `M ${CX('decision_sanction')} ${B('decision_sanction')} V ${BUS} H ${CX('cloture')} V ${T('cloture')}` },
    { from: 'fin_procedure', d: `M ${CX('fin_procedure')} ${B('fin_procedure')} V ${BUS} H ${CX('cloture')} V ${T('cloture')}` },
  ];
  const labels = [
    { from: 'constatation_recue', text: 'Lancer l’analyse', x: CX('constatation_recue'), y: (B('constatation_recue') + T('analyse_gravite')) / 2 },
    { from: 'analyse_gravite', text: 'Faute non grave', x: (CX('analyse_gravite') + CX('sanction_faute_non_grave')) / 2, y: 196 },
    { from: 'analyse_gravite', text: 'Faute grave', x: CX('analyse_gravite'), y: (196 + T('convocation_seance')) / 2 },
    { from: 'sanction_faute_non_grave', text: 'puis Clos', x: CX('sanction_faute_non_grave'), y: 560 },
    { from: 'convocation_seance', text: 'Présent', x: CX('seance_presente'), y: (352 + T('seance_presente')) / 2 },
    { from: 'convocation_seance', text: 'Absent', x: CX('seance_absente'), y: (352 + T('seance_absente')) / 2 },
    { from: 'seance_presente', text: 'PV remis', x: CX('seance_presente'), y: (B('seance_presente') + T('pv_seance')) / 2 },
    { from: 'seance_absente', text: 'Dépôt', x: CX('seance_absente'), y: (B('seance_absente') + T('depot_inspection_absence')) / 2 },
    { from: 'depot_inspection_absence', text: 'Investigations', x: CX('depot_inspection_absence'), y: (B('depot_inspection_absence') + T('investigations')) / 2 },
    { from: 'pv investig', text: 'Même choix', x: 488, y: 772 },
    { from: 'decision_licenciement', text: '48 h', x: CX('notification_48h'), y: (918 + T('notification_48h')) / 2 },
    { from: 'decision_mise_a_pied', text: '48 h', x: CX('notification_48h'), y: (918 + T('notification_48h')) / 2 },
    { from: 'notification_48h', text: 'Dépôt', x: CX('notification_48h'), y: (B('notification_48h') + T('depot_inspection_decision')) / 2 },
    { from: 'depot_inspection_decision', text: 'Clos', x: (CX('depot_inspection_decision') + CX('cloture')) / 2, y: BUS },
    { from: 'decision_sanction', text: 'Clos', x: CX('decision_sanction'), y: 1040 },
    { from: 'fin_procedure', text: 'Clos', x: CX('fin_procedure'), y: 1040 },
  ];
  const hot = (from: string, id: string | null) => !!id && from.split(' ').includes(id);
  const selectedStep = steps.find(s => s.id === selectedId) || null;
  const nextIds = new Set(selectedStep?.next.map(n => n.id) || []);
  const placePop = useCallback(() => {
    if (!selectedId || !popRef.current) return;
    const card = document.querySelector(`.card[data-id="${selectedId}"]`) as HTMLElement | null;
    if (!card) return;
    const r = card.getBoundingClientRect();
    const pop = popRef.current;
    const bw = 340; const bh = pop.offsetHeight || 280;
    const vw = window.innerWidth; const vh = window.innerHeight; const gap = 12;
    let left = 0, top = 0, cls = '';
    if (r.right + gap + bw <= vw - 8) { cls = 'pop right'; left = r.right + gap; top = r.top - 4; }
    else if (r.left - gap - bw >= 8) { cls = 'pop left'; left = r.left - gap - bw; top = r.top - 4; }
    else if (vh - r.bottom > r.top) { cls = 'pop below'; left = Math.max(8, Math.min(r.left, vw - bw - 8)); top = r.bottom + gap; }
    else { cls = 'pop above'; left = Math.max(8, Math.min(r.left, vw - bw - 8)); top = r.top - gap - bh; }
    top = Math.max(8, Math.min(top, vh - Math.min(bh, vh - 16) - 8));
    left = Math.max(8, Math.min(left, vw - bw - 8));
    const tail = cls === 'pop right' || cls === 'pop left' ? r.top + r.height / 2 - top - 6 : r.left + r.width / 2 - left - 6;
    setPopStyle({ left, top, cls, tail: Math.max(16, tail) });
  }, [selectedId]);
  useEffect(() => { if (selectedId) requestAnimationFrame(() => placePop()); else setPopStyle(null); }, [selectedId, picked, mailRef, notice, placePop]);
  useEffect(() => {
    function onScrollResize() { if (selectedId) placePop(); }
    window.addEventListener('scroll', onScrollResize, true);
    window.addEventListener('resize', onScrollResize);
    return () => { window.removeEventListener('scroll', onScrollResize, true); window.removeEventListener('resize', onScrollResize); };
  }, [selectedId, placePop]);

  function needsNotify(stepId: string) {
    return stepId === 'convocation_seance';
  }
  function pick(ref: string) {
    setPicked((cur) => (cur === ref ? null : ref));
    setMailRef(null);
    setNotice('');
  }
  function openPreview(ref: string) {
    setPicked(ref);
    setMailRef((cur) => (cur === ref ? null : ref));
    setNotice('');
  }
  function decide(ref: string, to: string, label: string) {
    transitionCase(ref, to, label, 'Avancement');
    const s = getWorkflowState();
    const stepIds = new Set(STEP_META.map((step) => step.id));
    const cases = s.cases.map((c) => {
      if (c.reference !== ref) return c;
      const next = { ...c, etape: to };
      const current = (c as { statut?: unknown }).statut;
      if (typeof current === 'string' && (current === c.etape || stepIds.has(current) || current === '')) (next as { statut: string }).statut = to;
      return next;
    });
    setWorkflowState({ ...s, cases });
    setPicked(null);
    setMailRef(null);
    setNotice(ref + ' · ' + label + '. Étape du dossier : ' + (byId[to]?.label || to) + '.');
    setSelectedId(to);
  }

  const total = snap.cases.length;
  const enCours = snap.cases.filter(c => c.etape !== 'cloture').length;
  const clos = snap.cases.filter(c => c.etape === 'cloture').length;
  const retard = snap.cases.filter(c => c.etape !== 'cloture' && !!c.echeance && new Date(c.echeance) < new Date()).length;
  return (
    <div className="g-page jx-av">
      <style>{`
        .jx-av h1 { margin: 6px 0 4px; font-size: 26px; letter-spacing: -.035em; color: var(--g-text); font-weight: 760; }
        .jx-av .kicker { display: flex; align-items: center; gap: 8px; font-size: 10.5px; letter-spacing: .16em; text-transform: uppercase; color: #0e7490; font-weight: 800; }
        .jx-av .kicker i { width: 6px; height: 6px; border-radius: 50%; background: var(--g-cyan); display: inline-block; box-shadow: 0 0 0 3px rgba(8,145,178,.16); }
        .jx-av .lead { margin: 4px 0 14px; max-width: 820px; color: var(--g-muted); font-size: 13px; line-height: 1.55; }
        .jx-av .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 14px; }
        .jx-av .stat {
          background: var(--g-glass); border: 1px solid var(--g-stroke); border-radius: 18px; padding: 14px 16px;
          box-shadow: var(--g-shadow), inset 0 1px 0 rgba(255,255,255,.7);
          backdrop-filter: blur(var(--g-blur)) saturate(160%);
        }
        .jx-av .stat b { display: block; font-size: 26px; color: var(--g-text); letter-spacing: -.035em; font-variant-numeric: tabular-nums; }
        .jx-av .stat span { font-size: 11.5px; font-weight: 650; color: var(--g-muted); }
        .jx-av .stat.alert b { color: #be123c; }
        .jx-av .board {
          background: var(--g-glass); border: 1px solid var(--g-stroke); border-radius: 22px; padding: 16px 14px 20px; overflow: auto;
          box-shadow: var(--g-shadow), inset 0 1px 0 rgba(255,255,255,.7);
          backdrop-filter: blur(var(--g-blur)) saturate(160%);
        }
        .jx-av .board h2 { margin: 0 12px 2px; font-size: 15px; letter-spacing: -.02em; color: var(--g-text); font-weight: 730; }
        .jx-av .board .hint { margin: 0 12px 10px; color: var(--g-muted); font-size: 12px; }
        .jx-av .canvas { position: relative; width: 820px; height: 1288px; margin: 0 auto; }
        .jx-av svg.links { position: absolute; inset: 0; width: 820px; height: 1288px; z-index: 1; pointer-events: none; }
        .jx-av .card {
          position: absolute; width: 136px; min-height: 56px; padding: 7px 9px 8px; z-index: 2;
          border: 1px solid rgba(15,35,80,.12); background: rgba(255,255,255,.86); border-radius: 14px; text-align: left; cursor: pointer;
          transition: border-color .18s, box-shadow .18s, transform .18s, background .18s;
        }
        .jx-av .card:hover { border-color: rgba(8,145,178,.5); transform: translateY(-1px); box-shadow: 0 12px 24px -18px rgba(15,35,80,.6); }
        .jx-av .card.on { border-color: rgba(8,145,178,.75); background: rgba(8,145,178,.08); box-shadow: 0 0 0 3px rgba(8,145,178,.16); }
        .jx-av .card.next { border-color: rgba(8,145,178,.45); }
        .jx-av .card.empty { background: rgba(255,255,255,.55); }
        .jx-av .card.empty .n { color: #9aa6bd; }
        .jx-av .ong { font-size: 8.5px; letter-spacing: .1em; text-transform: uppercase; color: #0e7490; font-weight: 800; }
        .jx-av .n { font-size: 20px; line-height: 1.1; color: var(--g-text); letter-spacing: -.03em; font-weight: 750; }
        .jx-av .lab { font-size: 11.5px; font-weight: 750; line-height: 1.2; letter-spacing: -.01em; }
        .jx-av .sub { margin-top: 2px; font-size: 10px; color: var(--g-muted); }
        .jx-av .late { color: #be123c; font-weight: 750; }
        .jx-av .onarrow {
          position: absolute; z-index: 4; transform: translate(-50%, -50%);
          background: rgba(255,255,255,.95); border: 1px solid rgba(15,35,80,.14); border-radius: 999px; padding: 2px 8px;
          font-size: 10.5px; font-weight: 750; color: var(--g-text); white-space: nowrap; pointer-events: none; line-height: 1.4;
        }
        .jx-av .onarrow.hot { border-color: rgba(8,145,178,.6); color: #0e7490; background: #f0fdff; }
        .jx-av .pop {
          position: fixed; display: block; width: 340px; max-height: min(78vh, 640px); overflow: auto; z-index: 50;
          background: rgba(255,255,255,.97); border: 1px solid rgba(8,145,178,.28); border-radius: 18px;
          box-shadow: 0 24px 60px -30px rgba(11,19,48,.55); padding: 14px;
        }
        .jx-av .pop:before { content: ""; position: absolute; width: 12px; height: 12px; background: rgba(255,255,255,.97); border: 1px solid rgba(8,145,178,.28); transform: rotate(45deg); }
        .jx-av .pop.right:before { left: -7px; top: var(--tail, 22px); border-right: 0; border-top: 0; }
        .jx-av .pop.left:before { right: -7px; top: var(--tail, 22px); border-left: 0; border-bottom: 0; }
        .jx-av .pop.below:before { top: -7px; left: var(--tail, 28px); border-right: 0; border-bottom: 0; }
        .jx-av .pop.above:before { bottom: -7px; left: var(--tail, 28px); border-left: 0; border-top: 0; }
        .jx-av .pop h3 { margin: 0; font-size: 15px; color: var(--g-text); letter-spacing: -.02em; }
        .jx-av .pop .top { display: flex; justify-content: space-between; gap: 8px; align-items: start; }
        .jx-av .x {
          border: 1px solid rgba(15,35,80,.14); background: rgba(243,246,251,.9); width: 26px; height: 26px; border-radius: 50%;
          cursor: pointer; color: var(--g-muted); font-size: 16px; line-height: 1; flex: 0 0 26px;
        }
        .jx-av .x:hover { border-color: rgba(225,29,72,.4); color: #be123c; }
        .jx-av .where { margin: 4px 0 0; font-size: 12px; color: var(--g-muted); line-height: 1.45; }
        .jx-av .ensuite { margin: 12px 0; padding: 11px; border-radius: 14px; background: rgba(8,145,178,.06); border: 1px solid rgba(8,145,178,.18); }
        .jx-av .ensuite p { margin: 0 0 6px; font-size: 10px; letter-spacing: .1em; text-transform: uppercase; color: #0e7490; font-weight: 800; }
        .jx-av .ensuite button, .jx-av .go {
          display: block; width: 100%; text-align: left; margin-top: 6px; cursor: pointer;
          border: 1px solid rgba(15,35,80,.12); background: rgba(255,255,255,.92); border-radius: 12px; padding: 8px 10px;
          color: var(--g-text); font-size: 12.5px; font-weight: 700; transition: .18s;
        }
        .jx-av .ensuite button:hover, .jx-av .go:hover { border-color: rgba(37,99,235,.45); box-shadow: 0 10px 20px -16px rgba(37,99,235,.7); }
        .jx-av .go small { display: block; font-weight: 600; color: var(--g-muted); font-size: 11px; }
        .jx-av .pills { display: flex; flex-wrap: wrap; gap: 6px; margin: 8px 0; }
        .jx-av .pill { font-size: 10.5px; border-radius: 999px; padding: 3px 9px; font-weight: 800; }
        .jx-av .ok { background: rgba(16,185,129,.12); color: #047857; }
        .jx-av .bad { background: rgba(225,29,72,.1); color: #be123c; }
        .jx-av .wait { background: rgba(217,119,6,.12); color: #b45309; }
        .jx-av .mute { background: rgba(100,116,139,.12); color: #475569; }
        .jx-av ul.dossiers { list-style: none; margin: 0; padding: 0; display: grid; gap: 8px; max-height: 220px; overflow: auto; }
        .jx-av ul.dossiers li { border-top: 1px solid var(--g-line); padding-top: 8px; }
        .jx-av ul.dossiers li.on { background: rgba(8,145,178,.07); border-radius: 10px; padding: 8px; }
        .jx-av .ref { font-weight: 750; font-size: 12.5px; color: var(--g-text); }
        .jx-av .meta { font-size: 11.5px; color: var(--g-muted); line-height: 1.4; }
        .jx-av .note { margin: 10px 12px 0; color: var(--g-muted); font-size: 12px; line-height: 1.5; }
        .jx-av .refbtn, .jx-av .notify { border: 0; background: transparent; padding: 0; cursor: pointer; text-align: left; }
        .jx-av .refbtn { font-weight: 750; font-size: 12.5px; color: var(--g-text); text-decoration: underline; }
        .jx-av .refbtn.on { color: #0e7490; }
        .jx-av .notify {
          display: inline-block; margin-top: 4px; border-radius: 999px; padding: 4px 9px;
          background: linear-gradient(120deg,#2563eb,#0891b2); color: #fff; font-size: 10.5px; font-weight: 800;
        }
        .jx-av .preview { display: grid; gap: 6px; margin-top: 8px; padding: 11px; border-radius: 14px; background: rgba(241,245,249,.8); border: 1px solid var(--g-line); }
        .jx-av .preview p { margin: 0; font-size: 10px; letter-spacing: .1em; text-transform: uppercase; color: #0e7490; font-weight: 800; }
        .jx-av .preview .line { font-size: 12px; color: var(--g-text); line-height: 1.45; }
        .jx-av .preview .line b { display: inline-block; min-width: 52px; color: var(--g-muted); font-size: 11px; }
        .jx-av .preview pre { margin: 0; white-space: pre-wrap; font: inherit; font-size: 12px; line-height: 1.45; color: var(--g-text); }
        .jx-av .preview button { border: 0; border-radius: 999px; background: rgba(37,99,235,.1); color: #1d4ed8; padding: 6px 10px; font-weight: 800; cursor: pointer; }
        @media (max-width: 980px) { .jx-av .stats { grid-template-columns: 1fr 1fr; } }
        @media (max-width: 640px) { .jx-av .stats { grid-template-columns: 1fr 1fr; } }
      `}</style>
      <main className="page">
        <div className="kicker"><i></i> Données réelles · workflow partagé</div>
        <h1>Avancement</h1>
        <p className="lead">Le schéma se lit de haut en bas. La mention est sur la flèche. Un clic fait sortir la bulle. Une référence ouvre les sorties de ce dossier seul. Notifier, seulement sur Convocation, montre l'aperçu du mail. Les adresses ne se saisissent pas ici.</p>
        <section className="stats">
          <div className="stat"><b>{total}</b><span>Dossiers</span></div>
          <div className="stat"><b>{enCours}</b><span>En cours</span></div>
          <div className="stat"><b>{clos}</b><span>Clos</span></div>
          <div className="stat alert"><b>{retard}</b><span>En retard, parmi les en cours</span></div>
        </section>
        <section className="board">
          <h2>Schéma des constatations</h2>
          <p className="hint">Clique une carte. La bulle sort de cette carte.</p>
          <div className="canvas" id="canvas">
            <svg className="links" viewBox="0 0 820 1288">
              <defs>
                <marker id="ah" markerWidth="8" markerHeight="8" refX="6.5" refY="4" orient="auto"><path d="M0,0.8 L7,4 L0,7.2 Z" fill="#c5d0e0" /></marker>
                <marker id="ah-hot" markerWidth="8" markerHeight="8" refX="6.5" refY="4" orient="auto"><path d="M0,0.8 L7,4 L0,7.2 Z" fill="#0aa8bd" /></marker>
              </defs>
              {arrows.map((a, idx) => (
                <path key={idx} d={a.d} fill="none" stroke={hot(a.from, selectedId) ? '#0aa8bd' : '#c5d0e0'} strokeWidth={hot(a.from, selectedId) ? 2.4 : 1.6} strokeLinejoin="round" strokeLinecap="round" markerEnd={a.join ? undefined : (hot(a.from, selectedId) ? 'url(#ah-hot)' : 'url(#ah)')} data-from={a.from} />
              ))}
            </svg>
            {labels.map((lb, idx) => (
              <span key={idx} className={`onarrow ${hot(lb.from, selectedId) ? 'hot' : ''}`} style={{ left: lb.x, top: lb.y }} data-from={lb.from}>{lb.text}</span>
            ))}
            {steps.map(step => {
              const late = count(step, 'retard');
              const empty = step.dossiers.length === 0;
              const isOn = selectedId === step.id;
              const isNext = nextIds.has(step.id);
              return (
                <button key={step.id} type="button" data-id={step.id} className={`card ${empty ? 'empty' : ''} ${isOn ? 'on' : ''} ${isNext ? 'next' : ''}`} style={{ left: step.x, top: step.y }} onClick={() => { setPicked(null); setMailRef(null); setNotice(''); setSelectedId(prev => (prev === step.id ? null : step.id)); }}>
                  <div className="ong">{step.onglet}</div>
                  <div className="n">{step.dossiers.length}</div>
                  <div className="lab">{step.label}</div>
                  <div className="sub">{late ? <span className="late">{late} en retard</span> : (step.dossiers.length ? `${step.dossiers.length} dossier${step.dossiers.length > 1 ? 's' : ''}` : 'Aucun')}</div>
                </button>
              );
            })}
          </div>
          <p className="note">Références réelles du workflow partagé. Sanction directe, sanction et absence du fait vont au clos, sans inspection. Seuls le licenciement et la mise à pied passent par les 48 heures, puis par le dépôt.</p>
        </section>
      </main>
      {selectedStep && (
        <div ref={popRef} className={popStyle?.cls || 'pop right'} style={popStyle ? { left: popStyle.left, top: popStyle.top, ['--tail' as any]: `${popStyle.tail}px` } : { left: -9999, top: -9999 }}>
          <div className="top">
            <div>
              <h3>{selectedStep.label}</h3>
              <p className="where">{selectedStep.dossiers.length} dossier{selectedStep.dossiers.length > 1 ? 's' : ''} · onglet {selectedStep.onglet}</p>
            </div>
            <button className="x" type="button" aria-label="Fermer" onClick={() => setSelectedId(null)}>×</button>
          </div>
          <p className="where">{selectedStep.echeance}</p>
          <p className="where">La sortie se décide dossier par dossier. Clique une référence.</p>
          {selectedStep.dossiers.length ? (
            <>
              <div className="pills">
                {count(selectedStep, 'delai') ? <span className="pill ok">{count(selectedStep, 'delai')} dans le délai</span> : null}
                {count(selectedStep, 'retard') ? <span className="pill bad">{count(selectedStep, 'retard')} en retard</span> : null}
                {count(selectedStep, 'attente') ? <span className="pill wait">{count(selectedStep, 'attente')} en attente</span> : null}
                {count(selectedStep, 'clos') ? <span className="pill mute">{count(selectedStep, 'clos')} clos</span> : null}
              </div>
              <ul className="dossiers">
                {selectedStep.dossiers.map(d => (
                  <li key={d.ref} className={picked === d.ref ? 'on' : ''}>
                    <button type="button" className={`refbtn${picked === d.ref ? ' on' : ''}`} onClick={() => pick(d.ref)}>{d.ref}</button>
                    <div className="meta">{d.lob} · {d.agent}<br />{d.detail}</div>
                    {needsNotify(selectedStep.id) && <button type="button" className="notify" onClick={() => openPreview(d.ref)}>Notifier</button>}
                  </li>
                ))}
              </ul>
              {picked && selectedStep.dossiers.some(d => d.ref === picked) && (
                <div className="ensuite">
                  <p>Sortie suivante · {picked}</p>
                  {selectedStep.next.length ? selectedStep.next.map(nx => (
                    <button key={nx.id} type="button" className="go" onClick={() => decide(picked, nx.id, nx.label)}>
                      {nx.label}
                      <small>vers {byId[nx.id]?.label || nx.id}</small>
                    </button>
                  )) : <div className="where">Aucune sortie. Le dossier est clos.</div>}
                </div>
              )}
              </>
          ) : (
            <p className="where">Aucun dossier sur cette étape.</p>
          )}
          {mailRef && needsNotify(selectedStep.id) && <MailPreview dossier={mailRef} onClose={() => setMailRef(null)} />}
          {notice && <p className="where">{notice}</p>}
        </div>
      )}
    </div>
  );
}

function MailPreview({ dossier, onClose }: { dossier: string; onClose: () => void }) {
  const s = getWorkflowState();
  const c = s.cases.find((x) => x.reference === dossier);
  const appt = s.appointments.filter((a) => a.dossier === dossier).sort((a, b) => String(b.createdAt || b.debut).localeCompare(String(a.createdAt || a.debut)))[0];
  const when = appt ? new Date(appt.debut).toLocaleString('fr-FR') + ' · ' + appt.lieu : 'Créneau non encore posé.';
  const body = [
    'Convocation à une séance.',
    'Dossier : ' + dossier,
    'Agent : ' + agentLabel(c?.agentId),
    'Créneau : ' + when,
    'Cette note ne qualifie pas les faits.',
  ].join('\n');
  return (
    <div className="preview">
      <p>Aperçu · notification</p>
      <div className="line"><b>À</b> Agent du dossier · adresse ajoutée automatiquement</div>
      <div className="line"><b>Copie</b> TL et SPV · ajoutés automatiquement</div>
      <div className="line"><b>Objet</b> Convocation {dossier}</div>
      <pre>{body}</pre>
      <p className="where">Aperçu seulement. Aucune adresse n'est saisie, aucune n'est inventée, rien n'est envoyé.</p>
      <button type="button" onClick={onClose}>Fermer l'aperçu</button>
    </div>
  );
}
